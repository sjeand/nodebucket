import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private http: HttpClient) { }

  findAllTasks(empId: string) {
   return this.http.get(`/api/employees/${empId}/tasks`);
  }

  createTask(empId: string, task: string) {
    return this.http.post(`/api/employees/${empId}/tasks`, {text: task})
  }
}


