/*
=======================================================
  Title: Nodebucket
  Author: Professor Krasso
  Date: 11/03/2021
  Modified by: Sarah Jean Baptiste
  Description: Home Component
========================================================
*/

import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { TaskService } from 'src/app/task.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  employeeTasks: any;

  constructor(private taskService: TaskService, private cookieService: CookieService) { }

  getAllTasks() {
    const empId = this.cookieService.get('session_user');
    this.taskService.findAllTasks(empId).subscribe(res => {
      this.employeeTasks = res;
    });
  }

  ngOnInit(): void {
    this.getAllTasks();
  }

}
